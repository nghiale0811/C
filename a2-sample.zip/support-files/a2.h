int fac(int);
