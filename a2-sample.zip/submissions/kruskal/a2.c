#include "a2.h"

int fac(int n)
{
  f = 1;
  while (n > 0) {
    f *= n;
    n--;
  }
  return f;
}
