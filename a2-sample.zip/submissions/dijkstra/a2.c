#include "a2.h"

int fac(int n)
{
  int f = 1;
  while (n > 0) {
    f *= n;
    n--;
  }
  return f;
}
