#include "a2.h"

int fac(int n)
{
  int f = 0;
  while (n > 0) {
    f *= n;
    n--;
  }
  return f;
}
