#include <stdio.h>
#include "a2.h"

int main(void)
{
  int answers[] = { 1, 1, 2, 6, 24, 120 };
  int n;
  for (n = 0; n < 6; n++) {
    if (fac(n) != answers[n]) {
      fprintf(stderr, "fac(%d) = %d\n", n, fac(n));
      return 1;
    }
  }
  return 0;
}
