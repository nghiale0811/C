#include "byos.h"
// Find out what other #include's you need! (E.g., see man pages.)

int interp(const struct cmd *c)
{
}
