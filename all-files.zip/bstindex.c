#include <stdio.h>
#include <string.h>
#include "bst.h"

// Find the ith smallest key in the tree file.  Store the answer at "answer".
// Return value: 0 if success and key found, -1 if anything goes wrong (e.g.,
// problem with reading file, i is out of range).
// The caller will make sure that "answer" points to enough space (40 bytes).
int bstindex(const char *filename, long i, char *answer)
{

}
