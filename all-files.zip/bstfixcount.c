#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

void bstfixcount(const char *filename)
{

}

int main(int argc, char **argv)
{
  if (argc < 2) {
    fprintf(stderr, "missing argument: filename\n");
    return 1;
  }

  bstfixcount(argv[1]);

  return 0;
}
