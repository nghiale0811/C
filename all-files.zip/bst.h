#ifndef _BST_H
#define _BST_H

typedef struct node {
  char key[40];                 // key, NUL-terminated C string
  unsigned long count;          // how many nodes in this subtree including self
  long left;                    // file offset of left child; -1L if none
  long right;                   // file offset of right child; -1L if none
} node;

int bstindex(const char *filename, long i, char *answer);

#endif
