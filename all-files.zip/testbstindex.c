#include <stdio.h>
#include "bst.h"

int main(void)
{
  for (int i = 0; i <= 16; i++) {
    char key[40];
    int r = bstindex("sample-tree.bin", i, key);
    if (r == -1) {
      printf("@%d none\n", i);
    } else {
      printf("@%d key=%s\n", i, key);
    }
  }

  return 0;
}
